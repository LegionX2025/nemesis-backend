import asyncio
import re
import logging
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

logger = logging.getLogger("OmniChainEngine.Scraper")

# Keywords to classify wallets
BEHAVIOR_KEYWORDS = {
    "MIXER": ["mixer", "tornado", "coinjoin", "blender", "tumbler", "mixing"],
    "CEX": ["exchange", "binance", "coinbase", "kraken", "kucoin", "okx", "huobi", "bybit", "cex", "custodial", "hot wallet", "cold wallet"],
    "DEX": ["dex", "uniswap", "sushiswap", "pancakeswap", "curve", "swap", "1inch", "amm", "liquidity"],
    "DEFI": ["defi", "lending", "aave", "compound", "maker", "yield", "vault", "staking"],
    "BRIDGE": ["bridge", "portal", "wormhole", "multichain", "layerzero", "hop", "stargate", "wrapped", "wrap", "unwrap"],
    "DARKNET": ["darknet", "silk road", "hydra", "black market", "sanctioned", "ofac", "blacklisted", "scam", "phishing", "hack", "exploiter"],
}

class AutoScraper:
    def __init__(self):
        self.playwright = None
        self.browser = None
        self.context = None
        
    async def start(self):
        try:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(
                headless=True,
                args=['--log-level=3', '--disable-logging']
            )
            self.context = await self.browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
            )
            logger.info("Playwright Auto-Scraper initialized.")
        except Exception as e:
            logger.error(f"Failed to initialize Playwright: {e}. Please ensure 'playwright install chromium' has been run.")

    async def stop(self):
        if self.context: await self.context.close()
        if self.browser: await self.browser.close()
        if self.playwright: await self.playwright.stop()
            
    def _classify_text(self, text: str) -> tuple:
        """Takes a blob of text from a block explorer and returns a cluster/label based on keywords."""
        if not text:
            return None, None
            
        text = text.lower()
        found_cluster = None
        found_label = None
        
        # Look for explicit names if we can extract them, otherwise just classify
        for cluster, keywords in BEHAVIOR_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    found_cluster = cluster
                    # Attempt to find a capitalized word near the keyword as the label
                    # Simplified: just use the keyword as a starting point
                    found_label = kw.title() + " " + cluster
                    # Specific overrides for well-known exchanges
                    if "binance" in text: found_label = "Binance"
                    if "coinbase" in text: found_label = "Coinbase"
                    if "kraken" in text: found_label = "Kraken"
                    if "tornado" in text: found_label = "Tornado Cash"
                    break
            if found_cluster:
                break
                
        return found_label, found_cluster

    async def scrape_ethplorer(self, address: str) -> tuple:
        """Scrape Ethplorer for Ethereum addresses."""
        if not self.context: return None, None
        page = await self.context.new_page()
        try:
            url = f"https://ethplorer.io/address/{address}"
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(2000) # Let react render
            content = await page.content()
            
            soup = BeautifulSoup(content, 'html.parser')
            # Extract tags and profile names
            tags = []
            for tag in soup.find_all('div', class_=lambda x: x and 'tag' in x.lower()):
                tags.append(tag.get_text(separator=' ', strip=True))
                
            text_blob = " | ".join(tags) + " " + soup.get_text()
            return self._classify_text(text_blob)
        except Exception as e:
            logger.error(f"Ethplorer scrape failed for {address}: {e}")
        finally:
            await page.close()

    async def scrape_blockscan(self, address: str) -> tuple:
        """Scrape Blockscan for multi-EVM addresses."""
        if not self.context: return None, None
        page = await self.context.new_page()
        try:
            url = f"https://blockscan.com/address/{address}"
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(2000) # Let react render
            content = await page.content()
            
            soup = BeautifulSoup(content, 'html.parser')
            tags = []
            for tag in soup.find_all(['span', 'a'], class_=lambda x: x and ('badge' in x.lower() or 'label' in x.lower() or 'btn' in x.lower())):
                tags.append(tag.get_text(separator=' ', strip=True))
                
            text_blob = " | ".join(tags) + " " + soup.get_text()
            return self._classify_text(text_blob)
        except Exception as e:
            logger.error(f"Blockscan scrape failed for {address}: {e}")
            return None, None
        finally:
            await page.close()

    async def scrape_oklink(self, address: str, chain: str) -> tuple:
        """Scrape OkLink using specific chain URL."""
        if not self.context: return None, None
        page = await self.context.new_page()
        try:
            chain_map = {
                "ETHEREUM": "eth", "MULTI-EVM": "eth", "EVM_AUTO": "eth", "ETH": "eth",
                "BSC": "bsc", "POLYGON": "polygon", "BASE": "base", 
                "ARBITRUM": "arbitrum", "OPTIMISM": "optimism",
                "BITCOIN": "btc", "SOLANA": "sol", "TRON": "trx", 
                "RIPPLE": "xrp", "STELLAR": "xlm"
            }
            ok_chain = chain_map.get(chain, "eth")
            url = f"https://www.oklink.com/{ok_chain}/address/{address}"
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            
            # Wait for network idle to ensure redirects complete before evaluation
            try:
                await page.wait_for_load_state("networkidle", timeout=8000)
            except:
                await page.wait_for_timeout(4000)
            
            # Use Playwright evaluation to grab all deeply nested text elements
            text_blob = await page.evaluate('''() => {
                const elements = Array.from(document.querySelectorAll('*'));
                // Filter elements that have direct text nodes to avoid massive duplication
                const textNodes = elements.filter(el => {
                    return Array.from(el.childNodes).some(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim().length > 0);
                });
                return textNodes.map(e => e.textContent.trim()).join(" | ");
            }''')
            
            return self._classify_text(text_blob)
        except Exception as e:
            logger.error(f"OkLink scrape failed for {address}: {e}")
            return None, None
        finally:
            await page.close()

    async def resolve_address(self, address: str, chain: str, trace_id: str = None) -> dict:
        """Master resolver that tries applicable block explorers."""
        label, cluster = None, None
        
        # Try Blockscan for EVM chains first as it's the best multichain label aggregator
        if chain in ["ETHEREUM", "MULTI-EVM", "EVM_AUTO", "ETH", "BSC", "POLYGON", "ARBITRUM", "OPTIMISM", "BASE"]:
            label, cluster = await self.scrape_blockscan(address)
        
        # Then try Ethplorer for ETH specifically
        if not label and chain in ["ETHEREUM", "MULTI-EVM", "EVM_AUTO", "ETH"]:
            label, cluster = await self.scrape_ethplorer(address)
            
        # Fallback or global use OkLink
        if not label:
            label, cluster = await self.scrape_oklink(address, chain)
            
        if label or cluster:
            result = {
                "address": address.lower(),
                "label": label or f"Identified {cluster}",
                "cluster": cluster or "UNKNOWN",
                "source": "Playwright Auto-Scraper"
            }
            
            # Save to MongoDB immediately
            from services.trace_engine import mongo_db
            if mongo_db is not None:
                try:
                    import datetime
                    await mongo_db.wallet_labels.update_one(
                        {"address": address.lower()},
                        {"$set": {"label": result["label"], "cluster": result["cluster"], "source": result["source"], "timestamp": datetime.datetime.now(datetime.timezone.utc)}},
                        upsert=True
                    )
                    logger.info(f"Playwright Scraper resolved {address}: {result['label']}")
                except Exception as e:
                    if "not authorized" in str(e).lower():
                        logger.warning("MongoDB skipped: Database user lacks 'update' permissions for wallet_labels.")
                    else:
                        logger.error(f"Mongo update failed in scraper: {e}")
            
            # Broadcast to active trace websocket
            if trace_id:
                try:
                    from main import active_sessions
                    if trace_id in active_sessions:
                        engine = active_sessions[trace_id]
                        # Broadcast LABEL_UPDATE
                        import json
                        for ws in list(engine.clients):
                            await ws.send_text(json.dumps({
                                "type": "LABEL_UPDATE",
                                "address": address.lower(),
                                "label": result["label"],
                                "cluster": result["cluster"]
                            }))
                except Exception as e:
                    logger.error(f"Failed to broadcast label update: {e}")
                    
            return result
        return None

# Global Singleton Scraper
scraper_instance = AutoScraper()
