
import os
os.environ["LOKY_MAX_CPU_COUNT"] = "4"
import re
from dotenv import load_dotenv
load_dotenv()
import json
import logging
from collections import defaultdict
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, Request, BackgroundTasks
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn
import uuid

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("OmniChainEngine")

from services.trace_engine import TraceEngine, init_mongodb, get_asset_ticker, detect_chain, EVM_DOMAINS, get_active_traces, get_mongo_status, fetch_saved_traces

import subprocess
import sys

async def run_boot_diagnostics():
    logger.info("==================================================")
    logger.info("   INITIATING LIONSGATE NEMESIS BOOT SEQUENCE     ")
    logger.info("==================================================")
    
    logger.info(">>> [1/5] Verifying Dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "google-genai", "--quiet"])
        logger.info("    [OK] google-genai and core dependencies verified.")
    except Exception as e:
        logger.error(f"    [FAIL] Could not verify dependencies: {e}")
        
    logger.info(">>> [2/5] Checking Intelligence Providers & API Keys...")
    from services.trace_engine import CONFIG
    providers = {
        "Etherscan": CONFIG.get("ETHERSCAN_API_KEY"),
        "OKLink": CONFIG.get("OKLINK_API_KEY"),
        "Tatum": os.getenv("TATUM_API_KEY"),
        "Gemini (AI)": os.getenv("GEMINI_API_KEYS")
    }
    for p, key in providers.items():
        if key and key != "freekey":
            logger.info(f"    [OK] {p} Provider Active.")
        else:
            logger.warning(f"    [WARN] {p} API Key missing or default.")
            
    logger.info(">>> [3/5] Loading Supported Networks...")
    logger.info(f"    [OK] EVM Chains: {', '.join(EVM_DOMAINS.keys())}")
    logger.info("    [OK] Non-EVM Chains: BITCOIN, SOLANA, TRON, RIPPLE, STELLAR")
    
    logger.info(">>> [4/5] Verifying Tracing Engine & Executions...")
    logger.info("    [OK] Tracing Engine Ready. Parallel Executions (Max 4 Workers).")
    
    logger.info(">>> [5/6] Fetching Data Modules...")
    logger.info("    [OK] Scraping fallback active. Asyncio data fetching pools ready.")
    
    logger.info(">>> [6/6] Triggering System Auto-Backup...")
    try:
        subprocess.Popen([sys.executable, "auto_backup.py"])
        logger.info("    [OK] Auto-backup routine dispatched to background.")
    except Exception as e:
        logger.error(f"    [FAIL] Could not dispatch auto-backup: {e}")
    
    logger.info("==================================================")
    logger.info("   NEMESIS ENGINE READY FOR OMNICHAIN OPERATIONS  ")
    logger.info("==================================================")

@asynccontextmanager
async def lifespan(app: FastAPI):
    await run_boot_diagnostics()
    import asyncio
    
    # Run MongoDB and Scraper initialization in the background so they don't block the web server from starting
    async def init_background():
        await init_mongodb()
        from services.scraper_engine import scraper_instance
        await scraper_instance.start()
        
    asyncio.create_task(init_background())
    
    yield
    from services.scraper_engine import scraper_instance
    await scraper_instance.stop()

app = FastAPI(title="Nemesis OmniChain API", description="Lionsgate OmniChain Forensic Engine", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="."), name="static")

active_sessions = {}

class TraceRequest(BaseModel):
    seeds: str
    target_amount: str = ""
    target_currency: str = "USD"
    start_date: str = ""
    end_date: str = ""
    chain_override: str = "AUTO"
    max_depth: int = 12
    max_hops: int = 1000

@app.get("/")
async def dashboard(request: Request):
    with open("templates/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache", "Expires": "0"})

@app.get("/admin")
async def admin_dashboard(request: Request):
    with open("templates/admin.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache", "Expires": "0"})

@app.get("/intelligence")
async def intelligence_dashboard(request: Request):
    with open("templates/nemesis_intelligence.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache", "Expires": "0"})

@app.get("/admin/health")
async def get_health():
    traces = get_active_traces(active_sessions)
    return {
        "active_websockets": sum(len(s.clients) for s in active_sessions.values()),
        "active_traces_count": len(traces),
        "mongo_connected": get_mongo_status(),
        "active_traces": traces
    }

@app.get("/admin/traces")
async def get_traces():
    return await fetch_saved_traces()

@app.post("/api/start_trace")
async def api_start_trace(req: TraceRequest, request: Request):
    try:
        raw_seeds = req.seeds.replace('"', '').replace("'", "")
        tokens = re.split(r'[\s,]+', raw_seeds)
        seeds_list = []
        for t in tokens:
            t = t.strip()
            if not t: continue
            chain = detect_chain(t, req.chain_override)
            if chain == "INVALID":
                continue
            if chain in EVM_DOMAINS or chain == "EVM_AUTO":
                t = t.lower()
            if t not in seeds_list:
                seeds_list.append(t)
                
        if not seeds_list: return {"error": "No valid seeds provided"}
        
        calc_amt = float(req.target_amount) if req.target_amount else 0.0
        trace_id = str(uuid.uuid4())[:8]
        
        engine = TraceEngine(trace_id)
        engine.setup(seeds_list, calc_amt, req.chain_override, req.start_date, req.end_date, req.target_currency, req.max_depth, req.max_hops)
        active_sessions[trace_id] = engine
        
        client_ip = request.client.host if request.client else "unknown"
        engine.client_ip = client_ip
        
        # We don't start the background task until the WS connects
        return {"status": "started", "trace_id": trace_id}
    except Exception as e:
        logger.error(f"Failed to setup trace: {e}")
        return {"error": str(e)}

@app.websocket("/ws/{trace_id}")
async def ws(websocket: WebSocket, trace_id: str):
    await websocket.accept()
    if trace_id not in active_sessions:
        await websocket.send_json({"type": "ERROR", "message": "Invalid trace ID"})
        await websocket.close()
        return
        
    engine = active_sessions[trace_id]
    engine.clients.add(websocket)
    
    await websocket.send_json({
        "type": "INIT",
        "seeds": engine.seeds,
        "seed_chains": engine.seed_chains
    })
    
    # Start engine loop if not started
    if not engine.is_running:
        engine.is_running = True
        import asyncio
        asyncio.create_task(engine.run())
        
    try:
        while True: await websocket.receive_text()
    except:
        engine.clients.discard(websocket)

@app.get("/api/wallet_profile/{address}")
async def wallet_profile(address: str, chain: str = "AUTO"):
    from services.trace_engine import detect_chain, CONFIG, EVM_DOMAINS
    import aiohttp
    
    chain_res = detect_chain(address, chain)
    balances = []
    
    if chain_res in EVM_DOMAINS or chain_res == "EVM_AUTO":
        actual_chain = chain_res if chain_res in EVM_DOMAINS else "ETHEREUM"
        domain = EVM_DOMAINS.get(actual_chain, "api.etherscan.io")
        api_key = CONFIG.get(f"{actual_chain}SCAN_API_KEY", CONFIG.get("ETHERSCAN_API_KEY", ""))
        
        import ssl
        import certifi
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_ctx)
        
        async with aiohttp.ClientSession(connector=connector) as session:
            try:
                # Fetch Native Balance
                url_native = f"https://{domain}/api?module=account&action=balance&address={address}&tag=latest&apikey={api_key}"
                async with session.get(url_native, timeout=10) as r:
                    if r.status == 200:
                        data = await r.json()
                        if data.get("status") == "1":
                            bal = float(data.get("result", 0)) / 1e18
                            if bal > 0:
                                ticker = "ETH" if actual_chain == "ETHEREUM" else "BNB" if actual_chain == "BSC" else "MATIC" if actual_chain == "POLYGON" else "NATIVE"
                                balances.append({"token": ticker, "balance": round(bal, 4), "usd_value": round(bal * 3000, 2)}) # Mock USD rate for UI
            except: pass
            
    return {"address": address, "chain": chain_res, "balances": balances}

@app.get("/api/nemesis_id/search")
async def search_nemesis_id(query: str):
    from services.trace_engine import mongo_db
    if mongo_db is None:
        return {"error": "Database not connected"}
    try:
        doc = await mongo_db.traces_data.find_one({
            "$or": [
                {"ledger.sender_nemesis_id": query},
                {"ledger.receiver_nemesis_id": query},
                {"trace_id": query}
            ]
        }, {"_id": 0})
        if doc and "ledger" in doc:
            return {"trace_id": doc.get("trace_id"), "ledger": doc.get("ledger")}
        return {"error": "Trace or Nemesis ID not found"}
    except Exception as e:
        logger.error(f"Error fetching trace by ID: {e}")
        return {"error": str(e)}

class DeepEvidenceRequest(BaseModel):
    tx: str
    chain: str = ""
    signature_hash: str = ""
    contract_method: str = ""
    raw_input_data: str = ""
    sender: str = ""
    receiver: str = ""

@app.post("/api/deep_evidence")
async def api_deep_evidence(req: DeepEvidenceRequest):
    import aiohttp
    import ssl
    import certifi
    import json
    import os
    
    ssl_ctx = ssl.create_default_context(cafile=certifi.where())
    connector = aiohttp.TCPConnector(ssl=ssl_ctx)
    
    decoded_abi = "[]"
    gemini_summary = "No Gemini API key configured."
    
    # 4byte lookup if signature hash is provided
    if req.signature_hash and req.signature_hash.startswith("0x"):
        async with aiohttp.ClientSession(connector=connector) as session:
            try:
                url = f"https://www.4byte.directory/api/v1/signatures/?hex_signature={req.signature_hash}"
                async with session.get(url, timeout=5) as r:
                    if r.status == 200:
                        data = await r.json()
                        if data.get("count", 0) > 0:
                            decoded_abi = json.dumps(data["results"], indent=2)
            except Exception as e:
                logger.error(f"4byte error: {e}")
                
    # Use Gemini to summarize
    gemini_key = os.getenv("GEMINI_API_KEYS", "").split(",")[0]
    if gemini_key and gemini_key != "freekey":
        try:
            from google import genai
            client = genai.Client(api_key=gemini_key)
            prompt = f"Analyze this blockchain transaction for forensic evidence.\nChain: {req.chain}\nTX: {req.tx}\nSender: {req.sender}\nReceiver: {req.receiver}\nMethod: {req.contract_method}\nSig Hash: {req.signature_hash}\nInput Data: {req.raw_input_data}\n4byte results: {decoded_abi}\n\nHOW DID THE ASSETS LANDED FROM ETH to BITCOIN or vice versa if applicable? Summarize the technical evidence briefly and try to identify the tx hash on it from the receiver inputs."
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
            )
            gemini_summary = response.text
        except Exception as e:
            gemini_summary = f"Gemini Analysis Failed: {e}"

    return {
        "decoded_abi": decoded_abi,
        "contract_source_code": gemini_summary
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=3001)
