import os
import subprocess
import re
import sys
import shutil

def patch_file_urls(filepath):
    if not os.path.exists(filepath):
        print(f"    -> WARNING: {filepath} not found.")
        return
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Replace localhost URLs with Render production URLs
    content = re.sub(r'http://127\.0\.0\.1:5000', 'https://nemesis-backend-ymr5.onrender.com', content)
    content = re.sub(r'http://127\.0\.0\.1:8000', 'https://nemesis-backend-ymr5.onrender.com', content)
    content = re.sub(r'ws://127\.0\.0\.1:5000', 'wss://nemesis-backend-ymr5.onrender.com', content)
    content = re.sub(r'ws://127\.0\.0\.1:8000', 'wss://nemesis-backend-ymr5.onrender.com', content)
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"    -> Production URLs injected in {os.path.basename(filepath)}.")

def clean_directory(dir_path, keep_files=None):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        return
    if keep_files is None:
        keep_files = []
    
    for item in os.listdir(dir_path):
        if item in keep_files:
            continue
        item_path = os.path.join(dir_path, item)
        try:
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)
            else:
                os.remove(item_path)
        except Exception as e:
            print(f"    -> WARNING: Could not remove {item_path}: {e}")

def main():
    print("=== LIONSGATE NETWORK: FULL STACK DEPLOYMENT ===")
    
    print("\n[PRE-FLIGHT] Cleaning up old deployment folders...")
    clean_directory("render_backend", keep_files=[".git", ".env"])
    clean_directory("cloudflare_frontend", keep_files=[".git", "package.json", "node_modules", "tailwind.config.js"])
    print("    -> Cleanup complete.")
    
    # 0. Sync root app.py to render_backend/app.py
    print("\n[0] Synchronizing Backend Files...")
    files_to_sync = ["app.py", "osint_orchestrator.py", "ml_clustering.py", "db_schema.py", "entity_scraper.py", "requirements.txt"]
    render_backend_dir = "render_backend"
    
    # Also sync the services module if needed, but keeping it to specified files for now
    for f in files_to_sync:
        if os.path.exists(f):
            shutil.copy2(f, os.path.join(render_backend_dir, f))
            print(f"    -> Copied {f} to {render_backend_dir}/{f}")
        else:
            print(f"    -> WARNING: {f} not found in root!")

    # 1. Sync frontend files
    print("\n[1] Synchronizing Frontend Files...")
    frontend_dir = "cloudflare_frontend"
    frontend_files = ["templates", "static"]
    
    for item in frontend_files:
        if os.path.exists(item):
            dst = os.path.join(frontend_dir, item)
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(item, dst)
            print(f"    -> Copied {item} to {frontend_dir}/{item}")
            
    # Also copy HTML files in root just in case
    for item in os.listdir("."):
        if item.endswith(".html"):
            shutil.copy2(item, os.path.join(frontend_dir, item))

    # 1b. Update frontend URLs for production
    print("\n[1b] Configuring frontend for production...")
    files_to_patch = ["templates/index.html", "tracer.html", "nemesis_id.html", "admin_dashboard.html", "landing.html", "nemesis_id_new.html"]
    
    for filename in files_to_patch:
        patch_file_urls(os.path.join(frontend_dir, filename))
        # Some files might be in root too
        patch_file_urls(filename)

    # 2. Deploy Frontend to Cloudflare R2
    print("\n[2] Deploying Frontend to Cloudflare R2...")
    # NOTE: user environment didn't have npm fully working before in the beta dir, 
    # but the script expects it. I'll wrap it in try-except so it doesn't fail the whole deployment.
    print('    -> Building Tailwind CSS...')
    try:
        subprocess.run('npm run build:css', cwd=frontend_dir, check=True, shell=True)
    except Exception as e:
        print(f"    -> WARNING: Tailwind build failed or not available: {e}. Proceeding anyway.")

    r2_script = "deploy_to_r2.py"
    if os.path.exists(r2_script):
        try:
            subprocess.run([sys.executable, r2_script], check=True)
        except subprocess.CalledProcessError as e:
            print(f"    -> ERROR: Cloudflare R2 deployment failed: {e}")
            # Proceed anyway
    else:
        print("    -> WARNING: deploy_to_r2.py not found in current directory. Skipping R2 deployment.")

    print("\n[2b] Deploying Frontend to Cloudflare Pages (Production)...")
    try:
        subprocess.run("npx wrangler pages deploy . --project-name nemesis-id-frontend --commit-dirty=true", cwd=frontend_dir, check=True, shell=True)
    except Exception as e:
        print(f"    -> WARNING: Cloudflare Pages deployment failed: {e}. Skipping.")

    # 3. Deploy Backend (Render via GitHub)
    print("\n[3] Backend Deployment (Render via GitHub)")
    render_backend_dir = "render_backend"
    if os.path.exists(render_backend_dir) and os.path.exists(os.path.join(render_backend_dir, ".git")):
        print(f"    -> Committing and pushing {render_backend_dir} to GitHub...")
        try:
            subprocess.run(["git", "rm", "--cached", ".env"], cwd=render_backend_dir, check=False)
            subprocess.run(["git", "add", "."], cwd=render_backend_dir, check=True)
            # Use check=False for commit in case there are no changes
            subprocess.run(["git", "commit", "-m", "Auto-deploy update: Metadata API injection & UI Dashboard fixes"], cwd=render_backend_dir, check=False) 
            subprocess.run(["git", "push", "origin", "main"], cwd=render_backend_dir, check=True)
            print("    -> Successfully pushed to GitHub. Render will now auto-deploy the backend.")
        except subprocess.CalledProcessError as e:
            print(f"    -> ERROR: Git push failed: {e}")
            sys.exit(1)
    else:
        print("    -> ERROR: render_backend/.git not found. Cannot auto-push to Render.")
        sys.exit(1)

    print("\n=== DEPLOYMENT COMPLETE ===")
    print("-> Frontend is live on Cloudflare R2.")
    print("-> Backend is deploying on Render via GitHub webhooks. Please wait 1-2 minutes.")

if __name__ == "__main__":
    main()
